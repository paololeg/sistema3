CREATE DATABASE IF NOT EXISTS `programacion3`;

USE `programacion3`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `caja`;

CREATE TABLE `caja` (
  `idCaja` int(11) NOT NULL AUTO_INCREMENT,
  `idUsuario` int(11) NOT NULL,
  `saldoInicial` decimal(9,2) NOT NULL,
  `saldoFinal` decimal(9,2) NOT NULL,
  `fechaCaja` date NOT NULL,
  `horaCaja` time NOT NULL,
  `estadoCaja` int(1) NOT NULL,
  PRIMARY KEY (`idCaja`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `caja` VALUES (1,33,"1500.00","50000.00","2021-03-08","01:17:00",1),
(9,33,"2600.00","112600.00","2021-03-10","07:11:12",1),
(10,33,"1000.00","18500.00","2021-03-10","08:53:26",1);


DROP TABLE IF EXISTS `categorias`;

CREATE TABLE `categorias` (
  `idCategoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombreCategoria` varchar(255) NOT NULL,
  PRIMARY KEY (`idCategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

INSERT INTO `categorias` VALUES (8,"Emisivo Nacional"),
(9,"Emisivo Internacional"),
(10,"Receptivo internacional USD"),
(11,"Receptivo Nacional"),
(12,"Estudiantil"),
(14,"Venta dolares"),
(15,"venta euros"),
(16,"venta pre viaje"),
(17,"Cancelacion 2020"),
(18,"cancelacion 2021"),
(19,"Venta corporativa");


DROP TABLE IF EXISTS `cuentaproveedor`;

CREATE TABLE `cuentaproveedor` (
  `idCuentaProveedor` int(11) NOT NULL AUTO_INCREMENT,
  `idUsuario` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `detalle` text NOT NULL,
  `debe` decimal(9,2) NOT NULL,
  `haber` decimal(9,2) NOT NULL,
  PRIMARY KEY (`idCuentaProveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;

INSERT INTO `cuentaproveedor` VALUES (1,12,"2020-10-12 11:20:45","Servicios aéreos","3750.00","0.00"),
(2,12,"2020-10-13 11:21:42","Servicios terrestres","2500.00","0.00"),
(9,12,"2020-10-13 10:08:03","servicios hotel 2021","4500.00","0.00"),
(10,12,"2020-10-13 10:12:53","pago a cuenta octubre 2020","0.00","6000.00"),
(16,15,"2020-10-13 11:42:06","prueba","1200.00","0.00"),
(17,28,"2020-10-13 11:44:07","prueba2","0.00","1200.00"),
(19,11,"2020-10-13 11:49:26","traslados in","0.00","8500.00"),
(20,28,"2020-10-13 11:51:05","servicios varios","18000.00","0.00"),
(21,15,"2020-10-13 11:52:59","prueba","0.00","1200.00"),
(22,15,"2020-10-13 11:54:36","ajuste ","1000.00","0.00"),
(24,11,"2020-11-25 23:13:42","pago a cuenta nov","0.00","1000.00"),
(25,11,"2020-11-25 23:14:18","servicios varios","15000.00","0.00"),
(26,11,"2021-03-10 08:59:50","servicios hotel 2021","5000.00","0.00");


DROP TABLE IF EXISTS `detallesfacturas`;

CREATE TABLE `detallesfacturas` (
  `idDetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idFactura` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `cantidadProducto` int(11) NOT NULL,
  `precio` decimal(9,2) NOT NULL,
  `subtotal` decimal(9,2) NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  PRIMARY KEY (`idDetalle`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4;

INSERT INTO `detallesfacturas` VALUES (1,2,6,1,"275000.00","275000.00",33),
(2,2,6,1,"275000.00","275000.00",33),
(4,3,6,1,"275000.00","275000.00",33),
(5,3,6,1,"275000.00","275000.00",33),
(6,3,1,1,"245000.00","245000.00",33),
(7,4,6,1,"275000.00","275000.00",33),
(8,4,6,1,"275000.00","275000.00",33),
(9,4,1,1,"245000.00","245000.00",33),
(10,5,1,1,"245000.00","245000.00",33),
(11,5,1,1,"245000.00","245000.00",33),
(12,6,1,1,"245000.00","245000.00",33),
(13,7,6,1,"275000.00","275000.00",33),
(14,8,6,1,"275000.00","275000.00",33),
(15,9,6,1,"275000.00","275000.00",33),
(16,10,6,1,"275000.00","275000.00",33),
(17,11,6,1,"275000.00","275000.00",33),
(18,12,6,1,"275000.00","275000.00",33),
(19,13,6,1,"275000.00","275000.00",33),
(21,14,6,1,"275000.00","275000.00",33),
(22,14,6,1,"275000.00","275000.00",33),
(23,15,6,1,"275000.00","275000.00",33),
(24,15,3,1,"130000.00","130000.00",33),
(25,16,6,1,"275000.00","275000.00",33),
(26,16,3,1,"130000.00","130000.00",33),
(27,17,6,1,"275000.00","275000.00",33),
(28,18,6,1,"275000.00","275000.00",33),
(29,19,6,1,"275000.00","275000.00",33),
(30,20,6,1,"275000.00","275000.00",33),
(31,21,6,1,"275000.00","275000.00",33),
(32,21,6,1,"275000.00","275000.00",33),
(33,21,6,1,"275000.00","275000.00",33),
(34,21,6,1,"275000.00","275000.00",33),
(35,21,6,1,"275000.00","275000.00",33),
(37,0,7,1,"50000.00","50000.00",33),
(38,22,3,1,"130000.00","130000.00",33),
(39,22,7,1,"50000.00","50000.00",33);


DROP TABLE IF EXISTS `detallesoperaciones`;

CREATE TABLE `detallesoperaciones` (
  `idDetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idOperacion` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `cantidadPax` int(11) NOT NULL,
  `subVenta` decimal(9,2) NOT NULL,
  `subCosto` decimal(9,2) NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  PRIMARY KEY (`idDetalle`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;

INSERT INTO `detallesoperaciones` VALUES (4,1,7,1,"50000.12","30000.00",33),
(5,1,7,1,"50000.12","30000.00",33),
(8,1,7,1,"50000.12","30000.00",33),
(9,1,16,2,"700000.00","700000.00",33),
(10,2,18,2,"157800.00","137800.00",33),
(11,2,7,2,"100000.24","60000.00",33),
(12,2,11,1,"130000.00","90000.00",33),
(14,3,18,1,"78900.00","68900.00",33),
(15,3,17,1,"85000.00","75000.00",33),
(16,4,14,1,"56000.00","49000.00",33),
(17,4,12,1,"158000.10","135000.00",33),
(18,4,11,1,"130000.00","90000.00",33),
(19,4,17,1,"85000.00","75000.00",33),
(20,4,13,1,"230000.00","201000.00",33),
(21,5,12,1,"158000.10","135000.00",33),
(23,6,12,3,"474000.30","405000.00",33),
(24,6,18,1,"78900.00","68900.00",33),
(25,8,19,1,"150000.00","130000.00",33),
(26,8,12,1,"158000.10","135000.00",33),
(27,9,18,1,"78900.00","68900.00",33),
(28,9,14,2,"112000.00","98000.00",33),
(29,7,15,1,"258000.00","232000.00",33),
(30,7,15,2,"516000.00","464000.00",33);


DROP TABLE IF EXISTS `egresos`;

CREATE TABLE `egresos` (
  `idEgreso` int(11) NOT NULL AUTO_INCREMENT,
  `idCaja` int(11) NOT NULL,
  `tipoEgreso` varchar(50) NOT NULL,
  `idProveedor` int(11) DEFAULT NULL,
  `idOperacion` int(11) DEFAULT NULL,
  `descripcionEgreso` text NOT NULL,
  `importeEgreso` decimal(9,2) NOT NULL,
  `tipoValor` varchar(50) NOT NULL,
  `moneda` varchar(50) NOT NULL,
  `fechaEgreso` date NOT NULL,
  `horaEgreso` time NOT NULL,
  `anulado` int(1) NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  PRIMARY KEY (`idEgreso`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `egresos` VALUES (1,1,"manual",0,NULL,"limpieza de oficina","1000.00","efectivo","pesos","2021-03-08","15:45:24",0,33),
(2,1,"manual",NULL,NULL,"pago folleteria agencia","5000.00","efectivo","pesos","2021-03-09","00:15:41",0,33),
(4,1,"manual",NULL,NULL,"almuerzo reunion","3800.00","efectivo","pesos","2021-03-09","00:29:28",0,33),
(5,9,"manual",NULL,NULL,"Cuarto Egreso","4500.00","transferencia","pesos","2021-03-10","08:51:48",0,33),
(6,10,"manual",NULL,NULL,"pago folleteria agencia","3500.00","efectivo","pesos","2021-03-10","17:09:08",0,33);


DROP TABLE IF EXISTS `facturas`;

CREATE TABLE `facturas` (
  `idFactura` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `idVendedor` int(11) NOT NULL,
  `totalVenta` decimal(9,2) NOT NULL,
  `condicionVenta` int(11) NOT NULL,
  `comprobanteTarjeta` varchar(200) NOT NULL,
  `fechaVenta` datetime NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`idFactura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `facturas` VALUES (1,8,4,"0.00",99,"","2020-06-18 19:44:39",33,1),
(2,34,2,"0.00",4,32132132,"2020-07-01 21:58:10",33,2),
(3,9,2,"0.00",1,32321654,"2020-07-01 22:00:13",33,2),
(4,30,4,"0.00",1,222222,"2020-07-01 22:13:32",33,2),
(5,8,4,"0.00",1,222222,"2020-07-01 22:38:36",33,2),
(6,9,4,"0.00",2,222222,"2020-07-01 22:40:24",33,2),
(7,0,9,"222222.00",2,4,"2020-07-01 22:46:23",33,2),
(8,6,2,"222222.00",99,4,"2020-07-01 22:48:44",33,2),
(9,6,2,"0.00",4,222222,"2020-07-01 22:50:56",33,2),
(10,6,2,"0.00",4,222222,"2020-07-01 22:53:49",33,2),
(11,34,4,"0.00",4,222222,"2020-07-01 23:01:14",33,2),
(12,34,2,"275000.00",2,222222,"2020-07-01 23:07:49",33,2),
(13,30,4,"275000.00",1,222222,"2020-07-01 23:56:41",33,2),
(14,8,4,"550000.00",99,"","2020-07-02 14:59:43",33,2),
(15,30,2,"405000.00",99,"","2020-07-02 15:11:38",33,2),
(16,34,2,"0.00",1,23123444,"2020-07-02 16:41:50",33,2),
(17,34,4,"275000.00",1,222222,"2020-07-02 16:46:06",33,2),
(18,34,4,"916666.67",1,222222,"2020-07-02 16:46:51",33,2),
(19,34,4,"82500.00",1,222222,"2020-07-02 16:48:49",33,2),
(20,34,4,"357500.00",1,222222,"2020-07-02 16:51:55",33,2),
(21,9,4,"1375000.00",99,"","2020-07-25 16:10:21",33,2),
(22,23,4,"198000.00",2,132154,"2020-11-25 23:00:55",33,2),
(23,0,0,"222.00",0,"","0000-00-00 00:00:00",0,0);


DROP TABLE IF EXISTS `ingresos`;

CREATE TABLE `ingresos` (
  `idIngreso` int(11) NOT NULL AUTO_INCREMENT,
  `idCaja` int(11) NOT NULL,
  `tipoIngreso` varchar(50) NOT NULL,
  `idCliente` int(11) DEFAULT NULL,
  `idOperacion` int(11) DEFAULT NULL,
  `descripcionIngreso` varchar(50) NOT NULL,
  `importeIngreso` decimal(9,2) NOT NULL,
  `tipoValor` varchar(50) NOT NULL,
  `numeroComprobante` int(11) DEFAULT NULL,
  `moneda` varchar(50) NOT NULL,
  `fechaIngreso` date NOT NULL,
  `horaIngreso` time NOT NULL,
  `anulado` int(1) NOT NULL,
  `idRegistrante` int(1) NOT NULL,
  PRIMARY KEY (`idIngreso`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

INSERT INTO `ingresos` VALUES (8,1,"recibo",NULL,1,"ingreso op 1","56000.00","efectivo",0,"pesos","2021-03-08","23:07:59",0,33),
(10,1,"manual",NULL,0,"Cobro de comisiones despegar","5400.00","transferencia",0,"pesos","2021-03-08","23:09:51",0,33),
(12,1,"manual",NULL,0,"test","2300.00","efectivo",0,"pesos","2021-03-09","02:17:25",0,33),
(13,9,"manual",NULL,0,"ingreso op 1","5000.00","efectivo",0,"pesos","2021-03-10","07:12:10",0,33),
(14,9,"manual",NULL,0,"ingreso op 4","45000.00","efectivo",0,"pesos","2021-03-10","07:43:30",0,33),
(15,9,"recibo",NULL,3,"ingreso op 3","60000.00","efectivo",0,"pesos","2021-03-10","08:20:25",0,33),
(16,10,"manual",NULL,0,"venta de moneda ","6000.00","efectivo",0,"pesos","2021-03-10","08:54:09",0,33),
(17,10,"manual",NULL,0,"venta de moneda extranjera","15000.00","efectivo",0,"pesos","2021-03-10","17:09:43",0,33);


DROP TABLE IF EXISTS `operaciones`;

CREATE TABLE `operaciones` (
  `idOperacion` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `venta` decimal(9,2) NOT NULL,
  `costo` decimal(9,2) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  `salida` date NOT NULL,
  `regreso` date NOT NULL,
  `cantidadPax` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  `fechaCarga` datetime NOT NULL,
  `fechaActualizacion` datetime NOT NULL,
  PRIMARY KEY (`idOperacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `operaciones` VALUES (1,8,"850000.36","790000.00","LEGUIZAMON X 5 BUE-TUC-BUE AA",33,"2021-03-16","2021-03-22",3,1,"2021-03-06 20:38:06","2021-03-07 20:46:51"),
(2,6,"387800.24","287800.00","SORIA X 2 BARILOCHE AEREOS + TERRESTRES",33,"2021-05-03","2021-03-14",2,1,"2021-03-07 20:53:33","2021-03-07 20:53:33"),
(3,30,"163900.00","143900.00","BARILOCHE TODO INCLUIDO",33,"2021-06-01","2021-03-12",1,1,"2021-03-09 22:29:21","2021-03-09 22:29:21"),
(4,27,"659000.10","550000.00","Incluye aéreo + traslados + alojamiento + asistencia al viajero",33,"2021-03-31","2021-04-17",1,1,"2021-03-10 06:19:13","2021-03-10 07:45:33"),
(5,8,"158000.10","135000.00","LEGUIZAMON X 2 BUE-TUC-BUE",33,"2021-03-25","2021-03-28",2,1,"2021-03-10 08:48:53","2021-03-10 08:48:53"),
(6,30,"552900.30","473900.00","Incluye aéreo + traslados + alojamiento + asistencia al viajero",33,"2021-05-03","2021-03-19",2,1,"2021-03-10 17:12:58","2021-03-10 17:12:58"),
(7,27,"774000.00","696000.00","",33,"2021-03-05","2021-03-03",1,1,"2021-03-11 20:22:14","2021-03-11 20:22:14"),
(8,23,"308000.10","265000.00","LEGUIZAMON X 2 BUE-TUC",33,"2021-03-11","2021-03-12",1,1,"2021-03-11 21:40:36","2021-03-11 21:52:57"),
(9,9,"190900.00","166900.00","asistencia al viajero",33,"2021-03-21","2021-03-24",1,1,"2021-03-11 22:00:16","2021-03-11 22:00:16");


DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `idProducto` int(11) NOT NULL AUTO_INCREMENT,
  `nombreProducto` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  `codigo` text NOT NULL,
  `cantidad` int(5) NOT NULL,
  `precioVenta` decimal(9,2) NOT NULL,
  `precioCompra` decimal(9,2) NOT NULL,
  `fechaIngresop` datetime NOT NULL,
  `idCategoria` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

INSERT INTO `productos` VALUES (1,"Paquete a Cancún 2021","aéreo+traslados+alojamiento+asistencia al viajero","CUN21",0,"245000.00","213700.00","2020-06-10 10:31:28",9,1),
(3,"RM all inclusive","todo incluido","RIM20",15,"130000.00","90000.00","0000-00-00 00:00:00",9,33),
(6,"Nueva Zelanda - Estudiantil","Aéreos, traslados, alojamiento, seguro.","NZL",0,"275000.00","255000.00","2020-06-18 16:14:25",9,33),
(7,"Aereos buenos aires tucuman","asdfasdf","BUE",5,"50000.12","30000.00","2020-07-25 16:07:02",8,33),
(11,"cancun todo incluido","AER, TRASL, HOTEL","CANCUNALL21",1,"130000.00","90000.00","2020-10-14 23:27:16",9,33),
(12,"Buzios aereos + terrestres","Alojamiento, traslados, aereos","BRZ01",4,"158000.10","135000.00","2020-11-25 21:24:37",9,33),
(13,"mexico df all inclusive","paquete all inclusive pago contado en dolares","MEX20",4,"230000.00","201000.00","2020-11-26 01:37:59",14,33),
(14,"Aereos Venezuela","Aereos bue - car","VNZ21",0,"56000.00","49000.00","2020-11-26 01:42:03",9,33),
(15,"Paquete europa 21","Paquete a europa salida enero 21","EUR21",7,"258000.00","232000.00","2020-11-26 01:43:50",15,33),
(16,"Seña europa 2022","Seña a cuenta salida europa 2022","EUR22",13,"350000.00","350000.00","2020-11-26 01:45:14",15,33),
(17,"Bariloche enero 21","Alojamiento y traslados enero 21 htl 5 est","BRC2021",8,"85000.00","75000.00","2020-11-26 01:47:05",8,33),
(18,"PATAGONIA","PATAGONIA","PAT20",1,"78900.00","68900.00","2020-11-26 03:29:47",8,33),
(19,"CANCUN 2022","TODO INCLUIDO","CUN22",39,"150000.00","130000.00","2021-03-10 08:57:06",9,33);


DROP TABLE IF EXISTS `sueldo`;

CREATE TABLE `sueldo` (
  `idSueldo` int(11) NOT NULL AUTO_INCREMENT,
  `idUsuario` int(11) NOT NULL,
  `anioSueldo` varchar(4) NOT NULL,
  `mesSueldo` varchar(2) NOT NULL,
  `diasTrabajados` int(2) NOT NULL,
  `basico` decimal(9,2) NOT NULL,
  `obraSocial` varchar(50) NOT NULL,
  `antiguedad` int(2) NOT NULL,
  `diasFeriados` int(2) NOT NULL,
  `feriadosTrabajados` int(2) NOT NULL,
  `feriadosNoTrabajados` int(2) NOT NULL,
  `netoSueldo` decimal(9,2) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`idSueldo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sueldo` VALUES (1,14,2020,10,21,"46790.08","PRENSA",4,3,2,1,"0.00","2020-10-29"),
(2,1,2020,10,19,"46925.50","OSECAC",3,3,1,2,"42621.08","2020-10-29"),
(3,3,2020,10,25,"47400.06","OSDE BINARIO",10,4,1,3,"0.00","2020-10-29"),
(4,31,2020,09,23,"46790.08","SUBSIDIO DE SALUD",22,3,1,3,"0.00","2020-10-29"),
(5,4,2020,10,30,"46925.50","OSDE BINARIO",8,2,1,1,"44427.03","2020-11-05"),
(9,33,2020,10,28,"47400.06","OSECAC",10,3,1,2,"0.00","2020-11-18"),
(10,0,"<br ","<b",25,"47400.06","PRENSA",10,5,3,2,"0.00","2020-11-11"),
(11,25,2020,10,30,"46790.08","OSECAC",18,10,2,8,"0.00","2020-11-19"),
(12,24,2020,10,5,"46790.08","PRENSA",8,4,2,2,"0.00","2020-11-17"),
(13,4,2020,05,28,"46925.50","PRENSA",11,3,2,1,"0.00","2020-11-23"),
(14,5,2020,10,27,"47400.06","SUBSIDIO DE SALUD",6,7,4,3,"0.00","2020-11-26"),
(15,3,2020,11,29,"47400.06","OSECAC",9,8,4,4,"51028.65","2020-11-26"),
(16,33,2021,01,25,"46925.50","OSECAC",5,3,1,2,"43450.61","2021-03-10");


DROP TABLE IF EXISTS `tarjetas`;

CREATE TABLE `tarjetas` (
  `idTarjeta` int(11) NOT NULL AUTO_INCREMENT,
  `nombreTarjeta` varchar(50) NOT NULL,
  `cuotas` int(11) NOT NULL,
  `interes` decimal(9,2) NOT NULL,
  PRIMARY KEY (`idTarjeta`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tarjetas` VALUES (1,"Visa Ahora 12",12,"30.00"),
(2,"Mastercard Ahora 12",12,"10.00"),
(4,"Naranja Z 6",6,"5.00"),
(99,"EFECTIVO",0,"0.00");


DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) CHARACTER SET utf8 NOT NULL,
  `password` text NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `dni` int(10) NOT NULL,
  `edad` int(3) NOT NULL,
  `nacimiento` date NOT NULL,
  `domicilio` varchar(100) NOT NULL,
  `localidad` varchar(50) NOT NULL,
  `provincia` varchar(50) NOT NULL,
  `nacionalidad` varchar(50) NOT NULL,
  `telefono` varchar(13) NOT NULL,
  `email` varchar(200) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `fechaUsuario` datetime NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  `privilegio` int(1) NOT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usuarios` VALUES (1,"administrador","7c4a8d09ca3762af61e59520943dc26494f8941b\r\n","pepito","juan",123456,30,"2000-05-20","9 de julio 675","Monteros","Tucumán","Argentina",3123123,"pepito@gmail.com","M","2020-05-20 18:05:09",1,1),
(2,"Ventas1",1234,"García","María José",3123123,35,"2000-05-21","Castelar 300","San Miguel de Tucumán","Tucumán","Argentina","381 3343393","mjgarcia@gmail.com","F","2020-05-21 18:49:13",1,6),
(3,"froldan",1234,"Roldan","Facundo",33454509,33,"1987-02-15","Basail 900","BRS","Tucuman","Argentina","381 4434234","froldan@hotmail.com","M","2020-05-21 18:51:14",1,1),
(4,"dalvarez",1234,"Alvarez","Daniel",33555666,33,"1987-04-29","Lavalle 554","YB","Tucuman","Argentina","381 2452452","dalvarez@gmail.com","M","2020-05-21 19:03:03",1,6),
(5,"jsoria",1234,"Soria","Jose",32445556,34,"1987-04-02","ASDFA","SM","Tucuman","Argentina","381 3453463","jsoria@gmail.com","M","2020-05-21 19:03:04",1,3),
(6,"rsoria",1234,"Soria","Roberto",31445388,32,"1987-08-15","ASDF","SM","Tucuman","Argentina",3453453,"ASDF","M","2020-05-21 19:03:04",2,4),
(7,"egarcia",1234,"Garcia Quinteros","Estela",14977543,57,"1963-07-17","ADF","YB","Tucuman","Argentina",345345345,"garciaesteladelv@gmail.com","F","2020-05-21 19:03:04",1,4),
(8,"mleguizamon",1234,"Leguizamon","Maximiliano",34654122,30,"1990-04-24","ADSF","TV","Tucuman","Argentina",5345345,"ASDF","M","2020-05-21 19:03:04",2,4),
(9,"jleguizamon",1234,"Leguizamon","Jose",16216543,58,"1963-03-17","ADF","BRS","Tucuman","Argentina",353453453,"ASDF","M","2020-05-21 19:03:04",1,4),
(11,"asdfasd",1234,"fdasdfas","asdfasd",1231231,58,"0000-00-00","","","","","","","","0000-00-00 00:00:00",0,5),
(12,"rizutoan",1234,"Rizuto","Angel",15643839,58,"0000-00-00","","","","","","","","0000-00-00 00:00:00",0,5),
(14,"Carlosc",1234,"Carabajal","Carlos José",123123,30,"1233-03-12","talitas d","talitas","tucuman","argentinadk",234324,"carlos@gmail.com","M","0000-00-00 00:00:00",0,2),
(15,"Usuarioencr","348162101fc6f7e624681b7400b085eeac6df7bd","usuarioap1","Usuario1",14123123,41,"0000-00-00","","","","","","","","0000-00-00 00:00:00",0,5),
(22,"administrador1","348162101fc6f7e624681b7400b085eeac6df7bd","Leguizamón","Paolo",33050184,41,"1987-05-03","Cabildo 1334","San Miguel de Tucumán","Tucumán","Argentina",3815777397,"paololeguizamon@gmail.com","M","0000-00-00 00:00:00",0,1),
(23,"administrador233","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","Leguizamón","Paolo",55555555,41,"1987-05-03","cabildo","asdd","tuc","arg",123131,"admin233@gmail.com","M","0000-00-00 00:00:00",0,4),
(24,"ad","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","nistrador","admin",44599595,41,"0000-00-00","Castelar 364","tucuman","tucuman","",12312314,"adddd@gmail.com","F","0000-00-00 00:00:00",0,2),
(25,"cajero",1234,"Lopez","Guillermina",123123432,23,"2010-12-06","Castelar 364","San Miguel","Tucumán","Argentinadsd",1231231231,"usuario@usuario.com","F","0000-00-00 00:00:00",0,3),
(26,"ur","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","neta","uruguay",333999558,41,"2000-08-17","alskdfa","ñlkjfasl","ñlkjaslf","laksjf","ñlaksjdf","urug@gmail.com","m","2020-05-31 19:26:09",0,2),
(27,"indibb","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","garcia","indian",442102020,41,"2012-12-06","castelar","tucuman","tucuman","tucuman",123123,"ind@indi.com","f","2020-05-31 19:34:33",0,4),
(28,"ventas",1234,"Soria","Pedro",92830192,41,"1969-02-27","cabildo","tucuman","tucuaman","argentina",11230192,"ventas@gmail.com","F","2020-05-31 20:00:54",0,6),
(30,"administrador23","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","Perez","Pedro",66565656,41,"1987-07-17","san pablo","san pablo","tucuman","argentino",23423423,"admin23@gmail.com","M","2020-06-04 19:30:11",0,4),
(31,"Pablo","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","Gramajo","Luis",995,1,"2020-06-04","9 de julio","Simoca","Tucumán","Argentina",123123111,"pablo@gmail.com","M","2020-06-04 19:39:07",0,2),
(33,"administrador2",123456,"Garcia","José",31354798,41,"1984-10-06","Castelar 364","San Miguel De Tucuman","Tucumán","Argentina",03815777397,"ad2@gmail.com","F","2020-06-07 22:18:56",1,1),
(34,"Cliente","7c4a8d09ca3762af61e59520943dc26494f8941b","Clientes","CONSUMIDOR FINAL CF",32565487,67,"2001-08-05","Andes 350","VCP","Cordoba","Argentina",6549879,"cliente@gmail.com","O","2020-06-07 22:27:29",33,4),
(35,"cuki","7c4a8d09ca3762af61e59520943dc26494f8941b","Cakes inc","Cuki",398844494,40,"1996-03-18","Cabildo 1334","sm tuc","tuccuman","argentina",23232333,"cuki@gmail.com","F","2020-06-10 17:02:27",33,3),
(36,"administrador21","7c4a8d09ca3762af61e59520943dc26494f8941b","Leguizamón1","Paolo1",31323146,0,"1986-11-11","cabildo","San Miguel De Tucuman","Tucumán","ARGENTINA",03815777311,"paololeguizamo1n@gmail.com","M","2021-03-10 01:47:09",33,6),
(37,"administrador22","7c4a8d09ca3762af61e59520943dc26494f8941b","Leguizamón22","Paolo22",42568522,0,"1987-12-22",22,"San Miguel De Tucuman","Tucumán","ARGENTINA",03815777397,"paololeguiza22@gmail.com","M","2021-03-10 01:49:47",33,6),
(38,"vendedor2","7c4a8d09ca3762af61e59520943dc26494f8941b","Brito","Carlos",32555444,0,"1985-03-18","Av alem 456","San Miguel De Tucuman","Tucumán","Argentina",03815777397,"ventas2@agencia.com","M","2021-03-10 09:05:40",33,6);


SET foreign_key_checks = 1;
