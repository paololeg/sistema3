CREATE DATABASE IF NOT EXISTS `programacion3`;

USE `programacion3`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `caja`;

CREATE TABLE `caja` (
  `idCaja` int(11) NOT NULL AUTO_INCREMENT,
  `idUsuario` int(11) NOT NULL,
  `importeCaja` decimal(9,2) NOT NULL,
  `fechaCaja` date NOT NULL,
  `horaCaja` time NOT NULL,
  PRIMARY KEY (`idCaja`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `caja` VALUES (1,33,"555.33","2020-08-30","10:03:55"),
(2,33,"350.45","2020-09-03","20:02:18");


DROP TABLE IF EXISTS `categorias`;

CREATE TABLE `categorias` (
  `idCategoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombreCategoria` varchar(255) NOT NULL,
  PRIMARY KEY (`idCategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

INSERT INTO `categorias` VALUES (8,"Emisivo Nacional"),
(9,"Emisivo Internacional"),
(10,"Receptivo internacional USD"),
(11,"Receptivo Nacional"),
(12,"Estudiantil");


DROP TABLE IF EXISTS `cuentaproveedor`;

CREATE TABLE `cuentaproveedor` (
  `idCuentaProveedor` int(11) NOT NULL AUTO_INCREMENT,
  `idUsuario` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `detalle` text NOT NULL,
  `debe` decimal(9,2) NOT NULL,
  `haber` decimal(9,2) NOT NULL,
  PRIMARY KEY (`idCuentaProveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

INSERT INTO `cuentaproveedor` VALUES (1,12,"2020-10-12 11:20:45","Servicios aéreos","3750.00","0.00"),
(2,12,"2020-10-13 11:21:42","Servicios terrestres","2500.00","0.00"),
(9,12,"2020-10-13 10:08:03","servicios hotel 2021","4500.00","0.00"),
(10,12,"2020-10-13 10:12:53","pago a cuenta octubre 2020","0.00","6000.00"),
(16,15,"2020-10-13 11:42:06","prueba","1200.00","0.00"),
(17,28,"2020-10-13 11:44:07","prueba2","0.00","1200.00"),
(19,11,"2020-10-13 11:49:26","traslados in","0.00","8500.00"),
(20,28,"2020-10-13 11:51:05","servicios varios","18000.00","0.00"),
(21,15,"2020-10-13 11:52:59","prueba","0.00","1200.00"),
(22,15,"2020-10-13 11:54:36","ajuste ","1000.00","0.00");


DROP TABLE IF EXISTS `detallesfacturas`;

CREATE TABLE `detallesfacturas` (
  `idDetalle` int(11) NOT NULL AUTO_INCREMENT,
  `idFactura` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `cantidadProducto` int(11) NOT NULL,
  `precio` decimal(9,2) NOT NULL,
  `subtotal` decimal(9,2) NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  PRIMARY KEY (`idDetalle`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;

INSERT INTO `detallesfacturas` VALUES (1,2,6,1,"275000.00","275000.00",33),
(2,2,6,1,"275000.00","275000.00",33),
(4,3,6,1,"275000.00","275000.00",33),
(5,3,6,1,"275000.00","275000.00",33),
(6,3,1,1,"245000.00","245000.00",33),
(7,4,6,1,"275000.00","275000.00",33),
(8,4,6,1,"275000.00","275000.00",33),
(9,4,1,1,"245000.00","245000.00",33),
(10,5,1,1,"245000.00","245000.00",33),
(11,5,1,1,"245000.00","245000.00",33),
(12,6,1,1,"245000.00","245000.00",33),
(13,7,6,1,"275000.00","275000.00",33),
(14,8,6,1,"275000.00","275000.00",33),
(15,9,6,1,"275000.00","275000.00",33),
(16,10,6,1,"275000.00","275000.00",33),
(17,11,6,1,"275000.00","275000.00",33),
(18,12,6,1,"275000.00","275000.00",33),
(19,13,6,1,"275000.00","275000.00",33),
(21,14,6,1,"275000.00","275000.00",33),
(22,14,6,1,"275000.00","275000.00",33),
(23,15,6,1,"275000.00","275000.00",33),
(24,15,3,1,"130000.00","130000.00",33),
(25,16,6,1,"275000.00","275000.00",33),
(26,16,3,1,"130000.00","130000.00",33),
(27,17,6,1,"275000.00","275000.00",33),
(28,18,6,1,"275000.00","275000.00",33),
(29,19,6,1,"275000.00","275000.00",33),
(30,20,6,1,"275000.00","275000.00",33),
(31,21,6,1,"275000.00","275000.00",33),
(32,21,6,1,"275000.00","275000.00",33),
(33,21,6,1,"275000.00","275000.00",33),
(34,21,6,1,"275000.00","275000.00",33),
(35,21,6,1,"275000.00","275000.00",33);


DROP TABLE IF EXISTS `egresos`;

CREATE TABLE `egresos` (
  `idEgreso` int(11) NOT NULL AUTO_INCREMENT,
  `descripcionEgreso` text NOT NULL,
  `importeEgreso` decimal(9,2) NOT NULL,
  `fechaEgreso` date NOT NULL,
  `horaEgreso` time NOT NULL,
  PRIMARY KEY (`idEgreso`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `egresos` VALUES (1,"Primer egreso","1200.00","2020-09-02","18:51:52"),
(2,"Segundo egreso","2000.00","2020-09-10","18:51:52"),
(3,"Tercer Egreso","3000.00","2020-09-15","00:00:00"),
(5,"Cuarto Egreso","4000.00","2020-09-21","00:00:00"),
(7,"ültimo registro hh","500.21","2020-09-25","20:04:51");


DROP TABLE IF EXISTS `facturas`;

CREATE TABLE `facturas` (
  `idFactura` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `idVendedor` int(11) NOT NULL,
  `totalVenta` decimal(9,2) NOT NULL,
  `condicionVenta` int(11) NOT NULL,
  `comprobanteTarjeta` varchar(200) NOT NULL,
  `fechaVenta` datetime NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`idFactura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `facturas` VALUES (1,8,4,"0.00",99,"","2020-06-18 19:44:39",33,1),
(2,34,2,"0.00",4,32132132,"2020-07-01 21:58:10",33,2),
(3,9,2,"0.00",1,32321654,"2020-07-01 22:00:13",33,2),
(4,30,4,"0.00",1,222222,"2020-07-01 22:13:32",33,2),
(5,8,4,"0.00",1,222222,"2020-07-01 22:38:36",33,2),
(6,9,4,"0.00",2,222222,"2020-07-01 22:40:24",33,2),
(7,0,9,"222222.00",2,4,"2020-07-01 22:46:23",33,2),
(8,6,2,"222222.00",99,4,"2020-07-01 22:48:44",33,2),
(9,6,2,"0.00",4,222222,"2020-07-01 22:50:56",33,2),
(10,6,2,"0.00",4,222222,"2020-07-01 22:53:49",33,2),
(11,34,4,"0.00",4,222222,"2020-07-01 23:01:14",33,2),
(12,34,2,"275000.00",2,222222,"2020-07-01 23:07:49",33,2),
(13,30,4,"275000.00",1,222222,"2020-07-01 23:56:41",33,2),
(14,8,4,"550000.00",99,"","2020-07-02 14:59:43",33,2),
(15,30,2,"405000.00",99,"","2020-07-02 15:11:38",33,2),
(16,34,2,"0.00",1,23123444,"2020-07-02 16:41:50",33,2),
(17,34,4,"275000.00",1,222222,"2020-07-02 16:46:06",33,2),
(18,34,4,"916666.67",1,222222,"2020-07-02 16:46:51",33,2),
(19,34,4,"82500.00",1,222222,"2020-07-02 16:48:49",33,2),
(20,34,4,"357500.00",1,222222,"2020-07-02 16:51:55",33,2),
(21,9,4,"1375000.00",99,"","2020-07-25 16:10:21",33,2),
(22,0,0,"0.00",0,"","0000-00-00 00:00:00",0,0);


DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `idProducto` int(11) NOT NULL AUTO_INCREMENT,
  `nombreProducto` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  `codigo` text NOT NULL,
  `cantidad` int(5) NOT NULL,
  `precioVenta` decimal(9,2) NOT NULL,
  `precioCompra` decimal(9,2) NOT NULL,
  `fechaIngresop` datetime NOT NULL,
  `idCategoria` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `productos` VALUES (1,"Paquete a Cancún 2021","aéreo+traslados+alojamiento+asistencia al viajero","CUN21",0,"245000.00","213700.00","2020-06-10 10:31:28",9,1),
(3,"RM all inclusive","todo incluido","RIM20",15,"130000.00","90000.00","0000-00-00 00:00:00",9,33),
(6,"Nueva Zelanda - Estudiantil","Aéreos, traslados, alojamiento, seguro.","NZL",0,"275000.00","255000.00","2020-06-18 16:14:25",9,33),
(7,"Aereos buenos aires tucuman","asdfasdf","BUE",12,"50000.00","30000.00","2020-07-25 16:07:02",8,33),
(11,"cancun todo incluido","AER, TRASL, HOTEL","CANCUNALL21",3,"130000.00","90000.00","2020-10-14 23:27:16",9,33);


DROP TABLE IF EXISTS `sueldo`;

CREATE TABLE `sueldo` (
  `idSueldo` int(11) NOT NULL AUTO_INCREMENT,
  `idUsuario` int(11) NOT NULL,
  `anioSueldo` varchar(4) NOT NULL,
  `mesSueldo` varchar(2) NOT NULL,
  `diasTrabajados` int(2) NOT NULL,
  `basico` decimal(9,2) NOT NULL,
  `obraSocial` varchar(50) NOT NULL,
  `antiguedad` int(2) NOT NULL,
  `diasFeriados` int(2) NOT NULL,
  `feriadosTrabajados` int(2) NOT NULL,
  `feriadosNoTrabajados` int(2) NOT NULL,
  `netoSueldo` decimal(9,2) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`idSueldo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sueldo` VALUES (1,14,2020,10,21,"46790.08","PRENSA",4,3,2,1,"0.00","2020-10-29"),
(2,1,2020,10,19,"46925.50","OSECAC",3,3,1,2,"0.00","2020-10-29"),
(3,3,2020,10,25,"47400.06","OSDE BINARIO",10,4,1,3,"0.00","2020-10-29"),
(4,31,2020,09,23,"46790.08","SUBSIDIO DE SALUD",22,3,1,3,"0.00","2020-10-29"),
(5,4,2020,10,30,"46790.08","PRENSA",5,1,1,0,"0.00","2020-11-15"),
(6,4,2020,10,30,"46790.08","PRENSA",5,2,1,1,"0.00","2020-11-15");


DROP TABLE IF EXISTS `tarjetas`;

CREATE TABLE `tarjetas` (
  `idTarjeta` int(11) NOT NULL AUTO_INCREMENT,
  `nombreTarjeta` varchar(50) NOT NULL,
  `cuotas` int(11) NOT NULL,
  `interes` decimal(9,2) NOT NULL,
  PRIMARY KEY (`idTarjeta`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tarjetas` VALUES (1,"Visa Ahora 12",12,"30.00"),
(2,"Mastercard Ahora 12",12,"10.00"),
(4,"Naranja Z 6",6,"5.00"),
(99,"EFECTIVO",0,"0.00");


DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) CHARACTER SET utf8 NOT NULL,
  `password` text NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `dni` int(10) NOT NULL,
  `edad` int(3) NOT NULL,
  `nacimiento` date NOT NULL,
  `domicilio` varchar(100) NOT NULL,
  `localidad` varchar(50) NOT NULL,
  `provincia` varchar(50) NOT NULL,
  `nacionalidad` varchar(50) NOT NULL,
  `telefono` varchar(13) NOT NULL,
  `email` varchar(200) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `fechaUsuario` datetime NOT NULL,
  `idRegistrante` int(11) NOT NULL,
  `privilegio` int(1) NOT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usuarios` VALUES (1,"administrador","7c4a8d09ca3762af61e59520943dc26494f8941b\r\n","pepito","juan",123456,30,"2000-05-20","9 de julio 675","Monteros","Tucumán","Argentina",3123123,"pepito@gmail.com","M","2020-05-20 18:05:09",1,1),
(2,"Ventas",1234,"García","María José",3123123,35,"2000-05-21","Castelar 300","San Miguel de Tucumán","Tucumán","Argentina","381 3343393","mjgarcia@gmail.com","F","2020-05-21 18:49:13",1,6),
(3,"froldan",1234,"Roldan","Facundo",33454509,33,"1987-02-15","Basail 900","BRS","Tucuman","Argentina","381 4434234","froldan@hotmail.com","M","2020-05-21 18:51:14",1,1),
(4,"dalvarez",1234,"Alvarez","Daniel",33555666,33,"1987-04-29","Lavalle 554","YB","Tucuman","Argentina","381 2452452","dalvarez@gmail.com","M","2020-05-21 19:03:03",1,6),
(5,"jsoria",1234,"Soria","Jose",32445556,34,"1987-04-02","ASDFA","SM","Tucuman","Argentina","381 3453463","jsoria@gmail.com","M","2020-05-21 19:03:04",1,3),
(6,"rsoria",1234,"Soria","Roberto",31445388,32,"1987-08-15","ASDF","SM","Tucuman","Argentina",3453453,"ASDF","M","2020-05-21 19:03:04",2,4),
(7,"egarcia",1234,"Garcia Quinteros","Estela",14977543,57,"1963-07-17","ADF","YB","Tucuman","Argentina",345345345,"garciaesteladelv@gmail.com","F","2020-05-21 19:03:04",1,4),
(8,"mleguizamon",1234,"Leguizamon","Maximiliano",34654122,30,"1990-04-24","ADSF","TV","Tucuman","Argentina",5345345,"ASDF","M","2020-05-21 19:03:04",2,4),
(9,"jleguizamon",1234,"Leguizamon","Jose",16216543,58,"1963-03-17","ADF","BRS","Tucuman","Argentina",353453453,"ASDF","M","2020-05-21 19:03:04",1,4),
(11,"asdfasd",1234,"fdasdfas","asdfasd",1231231,58,"0000-00-00","","","","","","","","0000-00-00 00:00:00",0,5),
(12,"rizutoan",1234,"Rizuto","Angel",15643839,58,"0000-00-00","","","","","","","","0000-00-00 00:00:00",0,5),
(14,"Carlosc",1234,"Carabajal","Carlos José",123123,30,"1233-03-12","talitas d","talitas","tucuman","argentinadk",234324,"carlos@gmail.com","M","0000-00-00 00:00:00",0,2),
(15,"Usuarioencr","348162101fc6f7e624681b7400b085eeac6df7bd","usuarioap1","Usuario1",14123123,41,"0000-00-00","","","","","","","","0000-00-00 00:00:00",0,5),
(22,"administrador1","348162101fc6f7e624681b7400b085eeac6df7bd","Leguizamón","Paolo",33050184,41,"1987-05-03","Cabildo 1334","San Miguel de Tucumán","Tucumán","Argentina",3815777397,"paololeguizamon@gmail.com","M","0000-00-00 00:00:00",0,1),
(23,"administrador233","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","Leguizamón","Paolo",55555555,41,"1987-05-03","cabildo","asdd","tuc","arg",123131,"admin233@gmail.com","M","0000-00-00 00:00:00",0,4),
(24,"ad","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","nistrador","admin",44599595,41,"0000-00-00","Castelar 364","tucuman","tucuman","",12312314,"adddd@gmail.com","F","0000-00-00 00:00:00",0,2),
(25,"usuario","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","Bros","usuariosuper",123123432,23,"2010-12-06","Castelar 364","San Miguel","Tucumán","Argentinadsd",1231231231,"usuario@usuario.com","F","0000-00-00 00:00:00",0,3),
(26,"ur","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","neta","uruguay",333999558,41,"2000-08-17","alskdfa","ñlkjfasl","ñlkjaslf","laksjf","ñlaksjdf","urug@gmail.com","m","2020-05-31 19:26:09",0,2),
(27,"indibb","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","garcia","indian",442102020,41,"2012-12-06","castelar","tucuman","tucuman","tucuman",123123,"ind@indi.com","f","2020-05-31 19:34:33",0,4),
(28,"dba","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","oracle","dba",92830192,41,"1969-02-27","cabildo","tucuman","tucuaman","argentina",11230192,"dba@gmail.com","F","2020-05-31 20:00:54",0,5),
(30,"administrador23","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","Perez","Pedro",66565656,41,"1987-07-17","san pablo","san pablo","tucuman","argentino",23423423,"admin23@gmail.com","M","2020-06-04 19:30:11",0,4),
(31,"Pablo","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","Gramajo","Luis",995,1,"2020-06-04","9 de julio","Simoca","Tucumán","Argentina",123123111,"pablo@gmail.com","M","2020-06-04 19:39:07",0,2),
(33,"administrador2",123456,"Garcia","Jose",31354798,41,"1984-10-06","Castelar 364","San Miguel De Tucuman","Tucumán","Argentina",03815777397,"ad2@gmail.com","F","2020-06-07 22:18:56",1,1),
(34,"Cliente","7c4a8d09ca3762af61e59520943dc26494f8941b","Clientes","CONSUMIDOR FINAL",32565487,67,"2001-08-05","Andes 350","VCP","Cordoba","Argentina",6549879,"cliente@gmail.com","O","2020-06-07 22:27:29",33,4),
(35,"cuki","7c4a8d09ca3762af61e59520943dc26494f8941b","Cakes","Cuki",398844494,40,"1996-03-18","Cabildo 1334","sm tuc","tuccuman","argentina",23232333,"cuki@gmail.com","F","2020-06-10 17:02:27",33,3);


SET foreign_key_checks = 1;
